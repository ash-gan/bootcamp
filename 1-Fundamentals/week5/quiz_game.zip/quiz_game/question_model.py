
class Question:

    def __init__(self, question, options, answer) -> None:
        self.question = question
        self.options = options
        self.answer = answer
